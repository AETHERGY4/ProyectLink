<?php
/**
 * TESPROY - Repositorio de Proyectos (TESCHI)
 * Endpoint de Proyectos (Listado, Creación, Actualización y Eliminación)
 * Ruta: C:\xampp\htdocs\tesproy\api\proyectos.php
 */

require_once __DIR__ . '/conexion.php';

$pdo = getDB();
$method = $_SERVER['REQUEST_METHOD'];

// 1. LISTAR PROYECTOS (GET)
if ($method === 'GET') {
    $usuario_id = isset($_GET['usuario_id']) ? intval($_GET['usuario_id']) : 0;
    $maestro_id = isset($_GET['maestro_id']) ? intval($_GET['maestro_id']) : 0;
    $solo_donados = isset($_GET['donados']) && $_GET['donados'] == '1';

    $sql = "SELECT p.*, 
                   u.nombre as autor_nombre, u.correo as autor_correo,
                   m.nombre as maestro_nombre, m.cubiculo as maestro_cubiculo,
                   DATEDIFF(NOW(), p.ultimo_commit) as dias_inactividad_calc
            FROM proyectos p
            LEFT JOIN usuarios u ON p.usuario_id = u.id
            LEFT JOIN maestros m ON p.maestro_id = m.id
            WHERE 1=1";

    $params = [];

    if ($solo_donados) {
        $sql .= " AND (p.es_donado = 1 OR p.listo_para_donar = 1)";
    } elseif ($usuario_id > 0) {
        $sql .= " AND (p.usuario_id = ? OR p.id IN (SELECT proyecto_id FROM integrantes WHERE usuario_id = ?))";
        $params[] = $usuario_id;
        $params[] = $usuario_id;
    } elseif ($maestro_id > 0) {
        $sql .= " AND p.maestro_id = ?";
        $params[] = $maestro_id;
    }

    $sql .= " ORDER BY p.ultimo_commit DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $proyectos = $stmt->fetchAll();

    foreach ($proyectos as &$p) {
        $dias = intval($p['dias_inactividad_calc'] ?? 0);
        $p['dias_inactivo'] = $dias;
        $p['porcentaje_avance'] = floatval($p['porcentaje_avance'] ?? 0);
    }

    jsonRes(true, $proyectos);
}

// 2. CREAR NUEVO PROYECTO (POST)
if ($method === 'POST') {
    $data = getRequestBody();

    $usuario_id  = isset($data['usuario_id']) ? intval($data['usuario_id']) : 0;
    $nombre      = isset($data['nombre']) ? trim($data['nombre']) : '';
    $descripcion = isset($data['descripcion']) ? trim($data['descripcion']) : '';
    $asignatura  = isset($data['asignatura']) ? trim($data['asignatura']) : 'Titulación';
    $semestre    = isset($data['semestre']) ? trim($data['semestre']) : '8ISC21';
    $maestro_id  = !empty($data['maestro_id']) ? intval($data['maestro_id']) : null;
    $fecha_inicio= !empty($data['fecha_inicio']) ? $data['fecha_inicio'] : date('Y-m-d');
    $fecha_fin   = !empty($data['fecha_fin']) ? $data['fecha_fin'] : date('Y-m-d', strtotime('+4 months'));

    if ($usuario_id <= 0 || empty($nombre)) {
        jsonRes(false, null, "El nombre del proyecto y el ID del alumno creador son obligatorios.", 400);
    }

    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("INSERT INTO proyectos (usuario_id, nombre, descripcion, fecha_inicio, fecha_fin, semestre, asignatura, maestro_id, porcentaje_avance, ultimo_commit) 
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, NOW())");
        $stmt->execute([$usuario_id, $nombre, $descripcion, $fecha_inicio, $fecha_fin, $semestre, $asignatura, $maestro_id]);
        $newId = $pdo->lastInsertId();

        // Agregar al creador como integrante
        $stmtInt = $pdo->prepare("INSERT INTO integrantes (proyecto_id, usuario_id) VALUES (?, ?)");
        $stmtInt->execute([$newId, $usuario_id]);

        $pdo->commit();

        jsonRes(true, ["id" => $newId, "nombre" => $nombre], "Proyecto registrado exitosamente en MySQL.");
    } catch (PDOException $e) {
        $pdo->rollBack();
        jsonRes(false, null, "Error al crear proyecto en base de datos: " . $e->getMessage(), 500);
    }
}

// 3. ACTUALIZAR PROYECTO (PUT)
if ($method === 'PUT') {
    $data = getRequestBody();
    $id = isset($data['id']) ? intval($data['id']) : 0;

    if ($id <= 0) {
        jsonRes(false, null, "Falta el ID del proyecto.", 400);
    }

    $fields = [];
    $params = [];

    if (isset($data['nombre']))            { $fields[] = "nombre = ?";            $params[] = trim($data['nombre']); }
    if (isset($data['descripcion']))       { $fields[] = "descripcion = ?";       $params[] = trim($data['descripcion']); }
    if (isset($data['porcentaje_avance'])) { $fields[] = "porcentaje_avance = ?"; $params[] = intval($data['porcentaje_avance']); }
    if (isset($data['asignatura']))        { $fields[] = "asignatura = ?";        $params[] = trim($data['asignatura']); }
    if (isset($data['semestre']))          { $fields[] = "semestre = ?";          $params[] = trim($data['semestre']); }
    if (isset($data['maestro_id']))        { $fields[] = "maestro_id = ?";        $params[] = !empty($data['maestro_id']) ? intval($data['maestro_id']) : null; }
    if (isset($data['calificacion']))      { $fields[] = "calificacion = ?";      $params[] = floatval($data['calificacion']); }
    if (isset($data['comentario']))        { $fields[] = "comentario = ?";        $params[] = trim($data['comentario']); }
    if (isset($data['listo_para_donar']))   { $fields[] = "listo_para_donar = ?"; $params[] = $data['listo_para_donar'] ? 1 : 0; }
    if (isset($data['es_donado']))         { $fields[] = "es_donado = ?";         $params[] = $data['es_donado'] ? 1 : 0; }
    if (!empty($data['nuevo_commit']))     { $fields[] = "ultimo_commit = NOW()"; }

    if (empty($fields)) {
        jsonRes(false, null, "No hay cambios para actualizar.", 400);
    }

    $params[] = $id;
    $sql = "UPDATE proyectos SET " . implode(", ", $fields) . " WHERE id = ?";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        jsonRes(true, ["id" => $id], "Proyecto actualizado correctamente.");
    } catch (PDOException $e) {
        jsonRes(false, null, "Error al actualizar: " . $e->getMessage(), 500);
    }
}

// 4. ELIMINAR PROYECTO (DELETE)
if ($method === 'DELETE') {
    $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    if ($id <= 0) {
        jsonRes(false, null, "Falta el ID del proyecto a eliminar.", 400);
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM proyectos WHERE id = ?");
        $stmt->execute([$id]);
        jsonRes(true, ["id" => $id], "Proyecto eliminado correctamente.");
    } catch (PDOException $e) {
        jsonRes(false, null, "Error al eliminar proyecto: " . $e->getMessage(), 500);
    }
}

jsonRes(false, null, "Método HTTP no soportado.", 405);