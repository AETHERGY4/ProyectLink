import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Sparkles,
  HeartHandshake,
  Users,
  Calendar,
  Clock,
  GraduationCap,
  FileCode,
  FileText,
  Video,
  CheckCircle2,
  AlertTriangle,
  Plus,
  ArrowRight,
  Vote,
  ShieldCheck,
  Send,
  HelpCircle
} from 'lucide-react';
import { AIModal } from './AIModal';
import { getMesesInactividad, getEstadoAbandono, getPorcentajeTerminado } from '../utils/projectUtils';

interface DetalleProyectoModalProps {
  projectId: number;
  onClose: () => void;
}

export const DetalleProyectoModal: React.FC<DetalleProyectoModalProps> = ({
  projectId,
  onClose
}) => {
  const {
    proyectos,
    usuarios,
    maestros,
    integrantes,
    actividades,
    archivos,
    votaciones,
    currentUser,
    addActivity,
    toggleActivityStatus,
    voteDonation,
    reassignProjectAdvisor
  } = useApp();

  const [activeTab, setActiveTab] = useState<'info' | 'actividades' | 'archivos' | 'votacion'>('info');
  const [showAiModal, setShowAiModal] = useState(false);
  const [aiMode, setAiMode] = useState<'abandono' | 'reasignacion' | 'matching_alumno'>('abandono');
  const [newActivityName, setNewActivityName] = useState('');

  const proyecto = proyectos.find(p => p.id === projectId);
  if (!proyecto) return null;

  const projectMembers = integrantes
    .filter(i => i.proyecto_id === projectId)
    .map(i => {
      const u = usuarios.find(usr => usr.id === i.usuario_id);
      return {
        ...i,
        user: u || { id: i.usuario_id, nombre: `Usuario #${i.usuario_id}`, correo: '', carrera: 'ISC', semestre: '8vo', foto_perfil: '' }
      };
    });

  const projectActivities = actividades.filter(a => a.proyecto_id === projectId);
  const projectFiles = archivos.filter(f => f.proyecto_id === projectId);
  const projectVotes = votaciones.filter(v => v.proyecto_id === projectId);
  const advisor = maestros.find(m => m.id === proyecto.maestro_id);

  // User vote state
  const myVote = projectVotes.find(v => v.usuario_id === currentUser.id)?.voto;

  const handleCreateActivity = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newActivityName.trim()) return;
    addActivity({
      proyecto_id: projectId,
      nombre: newActivityName.trim(),
      miembro: currentUser.nombre,
      fecha_inicio: new Date().toISOString().substring(0, 10),
      fecha_fin: new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString().substring(0, 10),
      estado: 'pendiente'
    });
    setNewActivityName('');
  };

  const openAiWithMode = (mode: 'abandono' | 'reasignacion' | 'matching_alumno') => {
    setAiMode(mode);
    setShowAiModal(true);
  };

  const favorableVotes = projectVotes.filter(v => v.voto === 'a_favor').length;
  const totalNeeded = Math.max(1, Math.ceil(projectMembers.length * 0.5));

  const estado = getEstadoAbandono(proyecto);
  const meses = getMesesInactividad(proyecto);
  const pctTerminado = getPorcentajeTerminado(proyecto);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Top Header */}
        <div className="bg-slate-900 text-white p-5 sm:p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex flex-wrap items-center gap-2 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              {proyecto.asignatura}
            </span>
            <span className="text-xs text-slate-300 px-2 py-0.5 rounded-md bg-slate-800">
              {proyecto.semestre}
            </span>
            {proyecto.es_donado && (
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-md bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center space-x-1">
                <HeartHandshake className="w-3.5 h-3.5" />
                <span>Proyecto Donado al Repositorio</span>
              </span>
            )}
            {estado === 'abandonado' && (
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-md bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center space-x-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Alerta de Abandono (≥ 5 meses sin actividad)</span>
              </span>
            )}
            {estado === 'en_riesgo' && (
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center space-x-1">
                <Clock className="w-3.5 h-3.5" />
                <span>En Riesgo ({meses} meses sin entregas)</span>
              </span>
            )}
          </div>

          <h2 className="text-xl sm:text-2xl font-bold font-display text-white tracking-tight">
            {proyecto.nombre}
          </h2>

          <p className="text-xs sm:text-sm text-slate-300 mt-2 line-clamp-2 max-w-2xl">
            {proyecto.descripcion}
          </p>

          {/* Quick AI Action Toolbar */}
          <div className="flex flex-wrap gap-2 mt-4 pt-3 border-t border-slate-800">
            <button
              onClick={() => openAiWithMode('abandono')}
              className="px-3 py-1.5 rounded-lg bg-emerald-600/90 hover:bg-emerald-600 text-white text-xs font-bold flex items-center space-x-1.5 shadow-sm transition-all"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Auditar Riesgo de Abandono</span>
            </button>

            <button
              onClick={() => openAiWithMode('reasignacion')}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center space-x-1.5 transition-all"
            >
              <GraduationCap className="w-3.5 h-3.5 text-amber-400" />
              <span>Reasignar Asesor por Temática</span>
            </button>

            <button
              onClick={() => setActiveTab('votacion')}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center space-x-1.5 transition-all"
            >
              <Vote className="w-3.5 h-3.5 text-teal-400" />
              <span>Votación de Donación ({favorableVotes}/{totalNeeded})</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-4 sm:px-6 overflow-x-auto">
          <button
            onClick={() => setActiveTab('info')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all whitespace-nowrap ${
              activeTab === 'info'
                ? 'border-emerald-600 text-emerald-700 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Información & Equipo
          </button>
          <button
            onClick={() => setActiveTab('actividades')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all whitespace-nowrap flex items-center space-x-1.5 ${
              activeTab === 'actividades'
                ? 'border-emerald-600 text-emerald-700 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <span>Actividades & Entregables</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-200 text-slate-700">
              {projectActivities.length}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('archivos')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all whitespace-nowrap flex items-center space-x-1.5 ${
              activeTab === 'archivos'
                ? 'border-emerald-600 text-emerald-700 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <span>Código & Archivos</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-200 text-slate-700">
              {projectFiles.length}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('votacion')}
            className={`py-3 px-4 text-xs font-bold border-b-2 transition-all whitespace-nowrap flex items-center space-x-1.5 ${
              activeTab === 'votacion'
                ? 'border-emerald-600 text-emerald-700 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <HeartHandshake className="w-3.5 h-3.5 text-emerald-600" />
            <span>Votación de Donación</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="p-5 sm:p-6 max-h-[60vh] overflow-y-auto">
          
          {/* TAB 1: INFORMACIÓN GENERAL & ASESOR */}
          {activeTab === 'info' && (
            <div className="space-y-6">
              
              {/* Status Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[11px] font-bold text-slate-400 uppercase">Fechas de Desarrollo</span>
                  <p className="text-xs font-semibold text-slate-800 mt-1">
                    {proyecto.fecha_inicio} al {proyecto.fecha_fin}
                  </p>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[11px] font-bold text-slate-400 uppercase">Inactividad / Commits</span>
                  <p className="text-xs font-semibold text-slate-800 mt-1 truncate">
                    {proyecto.ultimo_commit || 'Sin commits recientes'}
                  </p>
                  <span className={`text-[10px] font-bold block mt-0.5 ${
                    meses >= 5 ? 'text-rose-600' : meses >= 3 ? 'text-amber-600' : 'text-emerald-600'
                  }`}>
                    {meses === 0 ? 'Activo este mes' : `${meses} meses sin subir entregas ${meses >= 5 ? '(Abandono)' : ''}`}
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[11px] font-bold text-slate-400 uppercase">Porcentaje de Terminado</span>
                  <div className="flex items-center space-x-2 mt-1">
                    <span className="text-sm font-bold text-slate-800">{pctTerminado}%</span>
                    <div className="flex-1 bg-slate-200 h-2 rounded-full overflow-hidden">
                      <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${pctTerminado}%` }} />
                    </div>
                  </div>
                  <span className="text-[10px] text-slate-500 font-semibold block mt-0.5">
                    {proyecto.calificacion !== null ? 'Dictaminado por asesor' : 'En desarrollo'}
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-[11px] font-bold text-slate-400 uppercase">Estado Académico</span>
                  <p className="text-base font-black text-emerald-700 mt-1">
                    {proyecto.calificacion !== null ? `${proyecto.calificacion}% Terminado` : 'Revisión en Proceso'}
                  </p>
                  <span className="text-[10px] text-slate-500">
                    {proyecto.calificacion !== null ? 'Dictamen acreditado' : 'Pendiente de dictamen'}
                  </span>
                </div>
              </div>

              {/* Asesor Docente Card */}
              <div className="p-4 rounded-xl bg-gradient-to-br from-slate-50 to-emerald-50/40 border border-slate-200">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-start space-x-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold">
                      <GraduationCap className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800">
                        Profesor Asesor Asignado (TESCHI)
                      </span>
                      <h4 className="text-sm font-bold text-slate-900 mt-0.5">
                        {advisor ? advisor.nombre : 'Sin profesor asesor asignado'}
                      </h4>
                      <p className="text-xs text-slate-500">
                        {advisor ? `${advisor.cubo_o_oficina} · ${advisor.correo}` : 'Se requiere vincular a un docente'}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => openAiWithMode('reasignacion')}
                    className="px-3 py-1.5 rounded-lg bg-white border border-emerald-300 text-emerald-800 text-xs font-bold hover:bg-emerald-50 transition-colors shadow-2xs self-start sm:self-auto flex items-center space-x-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Reasignar con IA</span>
                  </button>
                </div>

                {advisor && (
                  <div className="mt-3 pt-3 border-t border-slate-200/60 flex flex-wrap gap-1.5 items-center">
                    <span className="text-[10px] font-bold text-slate-500">Especialidades del Asesor:</span>
                    {advisor.especialidades.map((esp, i) => (
                      <span key={i} className="text-[10px] bg-white border border-slate-200 px-2 py-0.5 rounded-md text-slate-700">
                        {esp}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Team Members List */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  Equipo de Trabajo ({projectMembers.length} integrantes)
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {projectMembers.map((m) => (
                    <div key={m.id} className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center space-x-3">
                      <img
                        src={m.user.foto_perfil || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80"}
                        alt={m.user.nombre}
                        className="w-9 h-9 rounded-lg object-cover ring-1 ring-slate-300"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-slate-800 truncate">{m.user.nombre}</p>
                        <p className="text-[10px] text-slate-500 truncate">{m.user.carrera} · {m.user.semestre}</p>
                      </div>
                      {m.usuario_id === proyecto.usuario_id && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-100 text-amber-800">
                          Líder
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Tags & Tech */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Stack Tecnológico & Etiquetas
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {proyecto.tags.map((tag, i) => (
                    <span key={i} className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 border border-slate-200">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: ACTIVIDADES / KANBAN */}
          {activeTab === 'actividades' && (
            <div className="space-y-4">
              {/* Add activity form */}
              <form onSubmit={handleCreateActivity} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Agregar nueva actividad o hito del proyecto..."
                  value={newActivityName}
                  onChange={(e) => setNewActivityName(e.target.value)}
                  className="flex-1 text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 bg-white"
                />
                <button
                  type="submit"
                  className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center space-x-1 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  <span>Agregar</span>
                </button>
              </form>

              {/* Activity items */}
              <div className="space-y-2">
                {projectActivities.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-8">
                    No hay actividades registradas en este proyecto.
                  </p>
                ) : (
                  projectActivities.map((act) => (
                    <div
                      key={act.id}
                      onClick={() => toggleActivityStatus(act.id)}
                      className="p-3 rounded-xl border border-slate-200 hover:border-emerald-300 transition-all flex items-center justify-between cursor-pointer bg-white"
                    >
                      <div className="flex items-center space-x-3">
                        <button className="shrink-0 text-slate-400 hover:text-emerald-600">
                          {act.estado === 'completada' ? (
                            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                          ) : (
                            <div className="w-5 h-5 rounded-full border-2 border-slate-300 hover:border-emerald-500" />
                          )}
                        </button>
                        <div>
                          <p className={`text-xs font-semibold text-slate-800 ${act.estado === 'completada' ? 'line-through text-slate-400' : ''}`}>
                            {act.nombre}
                          </p>
                          <p className="text-[10px] text-slate-500">
                            Responsable: <span className="font-medium text-slate-700">{act.miembro}</span> · Plazo: {act.fecha_fin}
                          </p>
                        </div>
                      </div>

                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                        act.estado === 'completada' ? 'bg-emerald-100 text-emerald-800' :
                        act.estado === 'en_progreso' ? 'bg-amber-100 text-amber-800' :
                        'bg-slate-100 text-slate-600'
                      }`}>
                        {act.estado}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 3: ARCHIVOS Y REPOSITORIO */}
          {activeTab === 'archivos' && (
            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                <span className="text-slate-600">Archivos fuente, documentación técnica y video demostrativo.</span>
                <span className="font-bold text-slate-800">{projectFiles.length} entregables</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {projectFiles.map((f) => (
                  <div key={f.id} className="p-3.5 rounded-xl border border-slate-200 bg-white hover:border-emerald-300 transition-all flex items-start space-x-3">
                    <div className="p-2 rounded-lg bg-slate-100 text-slate-700 shrink-0">
                      {f.tipo === 'codigo' ? (
                        <FileCode className="w-5 h-5 text-indigo-600" />
                      ) : f.tipo === 'video' ? (
                        <Video className="w-5 h-5 text-rose-600" />
                      ) : (
                        <FileText className="w-5 h-5 text-emerald-600" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-slate-800 truncate">{f.nombre_archivo}</p>
                      <p className="text-[10px] text-slate-500 mt-0.5">{f.tamano} · {f.fecha_subida}</p>
                    </div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50 px-1.5 py-0.5 rounded-sm">
                      {f.tipo}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: VOTACIÓN DE DONACIÓN */}
          {activeTab === 'votacion' && (
            <div className="space-y-5">
              
              {/* Consensus status card */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center space-x-2">
                      <HeartHandshake className="w-5 h-5 text-emerald-700" />
                      <span className="text-xs font-bold uppercase tracking-wider text-emerald-900">
                        Proceso de Donación al Repositorio TESCHI
                      </span>
                    </div>
                    <h3 className="text-base font-bold text-slate-900 mt-1">
                      {proyecto.es_donado
                        ? '¡Proyecto Donado y Transferible a Estudiantes!'
                        : 'Votación Democrática del Equipo en Curso'}
                    </h3>
                  </div>
                  <span className="text-xs font-extrabold px-3 py-1 rounded-full bg-emerald-200 text-emerald-950">
                    {favorableVotes} de {totalNeeded} votos requeridos
                  </span>
                </div>

                <p className="text-xs text-slate-700 mt-2 leading-relaxed">
                  Para que un proyecto abandonado o finalizado pueda ser donado al repositorio general de alumnos de 7mo a 9no semestre, al menos el 50% de los integrantes originales deben votar favorablemente.
                </p>

                {/* Vote buttons for current user */}
                {!proyecto.es_donado && (
                  <div className="mt-4 pt-3 border-t border-emerald-200/60 flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs text-slate-600 font-medium">
                      Tu voto actual: <span className="font-bold uppercase text-slate-900">{myVote || 'Pendiente'}</span>
                    </span>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => voteDonation(projectId, currentUser.id, 'a_favor')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                          myVote === 'a_favor'
                            ? 'bg-emerald-600 text-white shadow-xs'
                            : 'bg-white text-emerald-700 border border-emerald-300 hover:bg-emerald-50'
                        }`}
                      >
                        Votar A Favor de Donar
                      </button>
                      <button
                        onClick={() => voteDonation(projectId, currentUser.id, 'en_contra')}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                          myVote === 'en_contra'
                            ? 'bg-rose-600 text-white shadow-xs'
                            : 'bg-white text-rose-700 border border-rose-300 hover:bg-rose-50'
                        }`}
                      >
                        Votar En Contra
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Members vote audit list */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Registro de Votos del Equipo
                </h4>
                <div className="space-y-2">
                  {projectMembers.map((m) => {
                    const v = projectVotes.find(vote => vote.usuario_id === m.usuario_id);
                    const status = v?.voto || 'pendiente';
                    return (
                      <div key={m.id} className="p-3 rounded-xl border border-slate-200 bg-white flex items-center justify-between">
                        <div className="flex items-center space-x-2.5">
                          <img
                            src={m.user.foto_perfil || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80"}
                            alt={m.user.nombre}
                            className="w-7 h-7 rounded-lg object-cover"
                          />
                          <div>
                            <p className="text-xs font-semibold text-slate-800">{m.user.nombre}</p>
                            <p className="text-[10px] text-slate-400">{v?.fecha_voto || 'Aún no ha votado'}</p>
                          </div>
                        </div>

                        <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full capitalize ${
                          status === 'a_favor' ? 'bg-emerald-100 text-emerald-800' :
                          status === 'en_contra' ? 'bg-rose-100 text-rose-800' :
                          'bg-amber-100 text-amber-800'
                        }`}>
                          {status === 'a_favor' ? 'A favor' : status === 'en_contra' ? 'En contra' : 'Pendiente'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={() => openAiWithMode('abandono')}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center space-x-1"
          >
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <span>Diagnóstico IA</span>
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-200 transition-colors"
          >
            Cerrar
          </button>
        </div>

      </div>

      {/* Embedded AI Modal */}
      {showAiModal && (
        <AIModal
          isOpen={showAiModal}
          onClose={() => setShowAiModal(false)}
          proyecto={proyecto}
          defaultMode={aiMode}
        />
      )}
    </div>
  );
};
