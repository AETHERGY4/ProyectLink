import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Plus, FolderPlus, GraduationCap, Calendar, Tag } from 'lucide-react';

interface NuevoProyectoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NuevoProyectoModal: React.FC<NuevoProyectoModalProps> = ({ isOpen, onClose }) => {
  const { addProject, maestros, currentUser } = useApp();

  const [nombre, setNombre] = useState('');
  const [asignatura, setAsignatura] = useState('Ingeniería de Software');
  const [semestre, setSemestre] = useState('8ISC21');
  const [descripcion, setDescripcion] = useState('');
  const [fechaInicio, setFechaInicio] = useState(new Date().toISOString().substring(0, 10));
  const [fechaFin, setFechaFin] = useState(new Date(Date.now() + 120 * 24 * 3600 * 1000).toISOString().substring(0, 10));
  const [maestroId, setMaestroId] = useState<number>(maestros[0]?.id || 1);
  const [tagsInput, setTagsInput] = useState('React, TypeScript, MySQL, API');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nombre.trim()) return;

    const tags = tagsInput
      .split(',')
      .map(t => t.trim())
      .filter(t => t.length > 0);

    addProject({
      usuario_id: currentUser.id,
      nombre: nombre.trim(),
      descripcion: descripcion.trim(),
      fecha_inicio: fechaInicio,
      fecha_fin: fechaFin,
      semestre,
      asignatura,
      maestro_id: Number(maestroId),
      calificacion: null,
      comentario: null,
      es_donado: false,
      fecha_donacion: null,
      usuario_id_actual: null,
      listo_para_donar: false,
      tags: tags.length > 0 ? tags : ['Proyecto'],
      dias_inactividad: 0,
      meses_inactividad: 0,
      estado_abandono: 'activo'
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="bg-slate-900 p-5 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <FolderPlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold font-display">Registrar Nuevo Proyecto</h3>
              <p className="text-xs text-slate-400">Repositorio Académico TESCHI</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
          
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Nombre del Proyecto *
            </label>
            <input
              type="text"
              required
              value={nombre}
              onChange={(e) => setNombre(e.target.value)}
              placeholder="Ej: Sistema de Monitoreo de Calidad de Aire con IoT"
              className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 bg-white"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Asignatura
              </label>
              <select
                value={asignatura}
                onChange={(e) => setAsignatura(e.target.value)}
                className="w-full text-xs px-3 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 bg-white"
              >
                <option value="Sistemas programables">Sistemas Programables</option>
                <option value="Gestion de proyectos">Gestión de Proyectos</option>
                <option value="Inteligencia Artificial">Inteligencia Artificial</option>
                <option value="Ingeniería de Software">Ingeniería de Software</option>
                <option value="Taller de Bases de Datos">Taller de Bases de Datos</option>
                <option value="Lenguajes y Autómatas II">Lenguajes y Autómatas II</option>
                <option value="Residencia Profesional">Residencia Profesional</option>
                <option value="Titulación">Titulación / Tesina</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Semestre / Grupo
              </label>
              <input
                type="text"
                value={semestre}
                onChange={(e) => setSemestre(e.target.value)}
                placeholder="Ej: 7ISC21, 8ISC21, 9ISC21"
                className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 bg-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Profesor Asesor
            </label>
            <select
              value={maestroId}
              onChange={(e) => setMaestroId(Number(e.target.value))}
              className="w-full text-xs px-3 py-2.5 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 bg-white"
            >
              {maestros.map(m => (
                <option key={m.id} value={m.id}>
                  {m.nombre} ({m.especialidades.slice(0, 2).join(', ')})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Fecha de Inicio
              </label>
              <input
                type="date"
                value={fechaInicio}
                onChange={(e) => setFechaInicio(e.target.value)}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 bg-white"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                Fecha de Entrega
              </label>
              <input
                type="date"
                value={fechaFin}
                onChange={(e) => setFechaFin(e.target.value)}
                className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 bg-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Descripción General
            </label>
            <textarea
              rows={3}
              value={descripcion}
              onChange={(e) => setDescripcion(e.target.value)}
              placeholder="Objetivos, alcance técnico y tecnologías principales que se usarán en el proyecto..."
              className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 bg-white resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
              Stack Tecnológico (separado por comas)
            </label>
            <input
              type="text"
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="Ej: Python, FastAPI, Docker, Tailwind"
              className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white"
            />
          </div>

          {/* Footer */}
          <div className="pt-3 border-t border-slate-200 flex justify-end space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 flex items-center space-x-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Guardar Proyecto</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
