import React from 'react';
import { useApp } from '../context/AppContext';
import {
  FileCheck,
  Award,
  TrendingUp,
  Clock,
  CheckCircle2,
  AlertCircle,
  GraduationCap,
  MessageSquare,
  AlertTriangle,
  Layers
} from 'lucide-react';
import { getMesesInactividad, getEstadoAbandono, getPorcentajeTerminado } from '../utils/projectUtils';

export const EstadoCalificacionesView: React.FC = () => {
  const { proyectos, maestros, currentUser, currentRole, currentMaestro, integrantes } = useApp();

  // Role-appropriate project selection: ONLY user's projects for students
  let myProjects: typeof proyectos = [];

  if (currentRole === 'maestro' && currentMaestro) {
    myProjects = proyectos.filter(p => p.maestro_id === currentMaestro.id);
  } else if (currentRole === 'administrador') {
    myProjects = proyectos;
  } else {
    const studentId = currentUser?.id;
    if (studentId) {
      const userProjectIds = integrantes
        .filter(i => i.usuario_id === studentId)
        .map(i => i.proyecto_id);

      myProjects = proyectos.filter(p => 
        p.usuario_id === studentId || userProjectIds.includes(p.id)
      );
    } else {
      myProjects = [];
    }
  }

  const evaluatedProjects = myProjects.filter(p => p.calificacion !== null);
  const pendingProjects = myProjects.filter(p => p.calificacion === null);

  const avgCompletion = myProjects.length > 0
    ? (myProjects.reduce((acc, p) => acc + getPorcentajeTerminado(p), 0) / myProjects.length).toFixed(1)
    : '0.0';

  const bestCompletion = myProjects.length > 0
    ? Math.max(...myProjects.map(p => getPorcentajeTerminado(p))).toFixed(0)
    : '0';

  // Counts by percentage buckets
  const excelente = myProjects.filter(p => getPorcentajeTerminado(p) >= 90).length;
  const bueno = myProjects.filter(p => getPorcentajeTerminado(p) >= 80 && getPorcentajeTerminado(p) < 90).length;
  const regular = myProjects.filter(p => getPorcentajeTerminado(p) >= 70 && getPorcentajeTerminado(p) < 80).length;
  const inicial = myProjects.filter(p => getPorcentajeTerminado(p) < 70).length;
  const pendientesDictamen = pendingProjects.length;

  return (
    <div className="space-y-6 pb-12">
      
      {/* Title */}
      <div>
        <div className="flex items-center space-x-2 text-emerald-700 text-xs font-bold uppercase tracking-wider mb-1">
          <FileCheck className="w-4 h-4" />
          <span>Dictámenes y Avance Curricular</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-bold font-display text-slate-900">
          Porcentaje de Terminado de Proyectos
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
          Avance real y porcentaje de terminado avalado por el asesor docente para materias de 7mo a 9no semestre.
        </p>
      </div>

      {myProjects.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200/90 p-10 sm:p-14 text-center max-w-2xl mx-auto shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-4 border border-emerald-100 ring-4 ring-emerald-50/50">
            <Layers className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold font-display text-slate-900">
            Aún no tienes proyectos registrados
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-2 max-w-md mx-auto leading-relaxed">
            Tu cuenta está limpia. En cuanto registres o colabores en un proyecto integrador, podrás monitorear aquí su porcentaje de terminado, revisiones y dictamen del docente.
          </p>
        </div>
      ) : (
        <>
          {/* Top Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center space-x-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Promedio de Terminado</span>
                <p className="text-2xl font-black text-slate-900 font-display mt-0.5">{avgCompletion}%</p>
                <p className="text-[11px] text-emerald-600 font-semibold">Avance global del alumno</p>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center space-x-4">
              <div className="w-12 h-12 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Dictaminados por Asesor</span>
                <p className="text-2xl font-black text-slate-900 font-display mt-0.5">
                  {evaluatedProjects.length} <span className="text-xs text-slate-400 font-normal">/ {myProjects.length}</span>
                </p>
                <p className="text-[11px] text-teal-600 font-semibold">{pendientesDictamen} pendientes de dictamen oficial</p>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center space-x-4">
              <div className="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
                <TrendingUp className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Mayor % Terminado</span>
                <p className="text-2xl font-black text-slate-900 font-display mt-0.5">{bestCompletion}%</p>
                <p className="text-[11px] text-indigo-600 font-semibold">Proyecto con mayor avance</p>
              </div>
            </div>
          </div>

          {/* Classification Bar */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Distribución por Porcentaje de Terminado
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-center">
                <p className="text-[11px] font-bold text-emerald-800">90% - 100%</p>
                <p className="text-xl font-black text-emerald-900 mt-0.5">{excelente}</p>
                <span className="text-[10px] text-emerald-700 font-medium">Titulación / Listo</span>
              </div>
              <div className="p-3 rounded-xl bg-teal-50 border border-teal-200 text-center">
                <p className="text-[11px] font-bold text-teal-800">80% - 89%</p>
                <p className="text-xl font-black text-teal-900 mt-0.5">{bueno}</p>
                <span className="text-[10px] text-teal-700 font-medium">Avanzado</span>
              </div>
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-center">
                <p className="text-[11px] font-bold text-amber-800">70% - 79%</p>
                <p className="text-xl font-black text-amber-900 mt-0.5">{regular}</p>
                <span className="text-[10px] text-amber-700 font-medium">En desarrollo</span>
              </div>
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-center">
                <p className="text-[11px] font-bold text-rose-800">&lt; 70%</p>
                <p className="text-xl font-black text-rose-900 mt-0.5">{inicial}</p>
                <span className="text-[10px] text-rose-700 font-medium">Fase inicial</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-100 border border-slate-200 text-center col-span-2 sm:col-span-1">
                <p className="text-[11px] font-bold text-slate-700">Sin Dictamen</p>
                <p className="text-xl font-black text-slate-800 mt-0.5">{pendientesDictamen}</p>
                <span className="text-[10px] text-slate-500 font-medium">En revisión</span>
              </div>
            </div>
          </div>

          {/* Projects Details */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Desglose de Proyectos y Porcentaje Avalado
            </h3>

            <div className="space-y-3">
              {myProjects.map((p) => {
                const advisor = maestros.find(m => m.id === p.maestro_id);
                const pctTerminado = getPorcentajeTerminado(p);
                const isDictaminado = p.calificacion !== null;
                const meses = getMesesInactividad(p);
                const estado = getEstadoAbandono(p);

                return (
                  <div
                    key={p.id}
                    className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-emerald-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="space-y-1.5 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-md border border-emerald-200">
                          {p.asignatura}
                        </span>
                        <span className="text-xs text-slate-400 font-semibold">{p.semestre}</span>
                        {estado === 'abandonado' && (
                          <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 border border-rose-200 flex items-center space-x-1">
                            <AlertTriangle className="w-3 h-3" />
                            <span>Abandono ({meses} meses sin entregas)</span>
                          </span>
                        )}
                        {estado === 'en_riesgo' && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-200 flex items-center space-x-1">
                            <Clock className="w-3 h-3" />
                            <span>En Riesgo ({meses} meses sin entregas)</span>
                          </span>
                        )}
                        {estado === 'activo' && (
                          <span className="text-[11px] text-slate-400 font-medium">
                            {meses === 0 ? 'Activo este mes' : `${meses} meses sin entregas`}
                          </span>
                        )}
                      </div>

                      <h4 className="text-base font-bold text-slate-900">{p.nombre}</h4>

                      <p className="text-xs text-slate-500 flex items-center space-x-1.5">
                        <GraduationCap className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>Asesor Docente: <strong>{advisor ? advisor.nombre : 'Sin asignar'}</strong></span>
                      </p>

                      {p.comentario && (
                        <div className="mt-2 p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-start space-x-2">
                          <MessageSquare className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                          <p><strong className="text-slate-800">Observaciones del Asesor:</strong> "{p.comentario}"</p>
                        </div>
                      )}
                    </div>

                    {/* Completion Percentage display */}
                    <div className="text-left sm:text-right shrink-0">
                      <div>
                        <span className="text-2xl sm:text-3xl font-black text-emerald-600 font-display">
                          {pctTerminado}%
                        </span>
                        <span className="block text-xs font-bold text-slate-700 mt-0.5">
                          Porcentaje de Terminado
                        </span>
                        <span className={`inline-block text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full mt-1 ${
                          isDictaminado
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : 'bg-amber-100 text-amber-800 border border-amber-200'
                        }`}>
                          {isDictaminado ? 'Dictamen Acreditado' : 'Avance en Desarrollo'}
                        </span>
                      </div>
                    </div>

                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}

    </div>
  );
};
